from unumposit.conversionposit import decimal_to_posit
from unumposit.conversionposit import posit_to_decimal
